# res_m_server
Server-side for Restaurant Menu Service

## Documentation 

API Documentation in directory build/dokka/html/index.html

## Installation

### Prerequisites

* [JDK 17 or later](https://www.oracle.com/java/technologies/downloads/#java17)
* Add the required Environmental Variables:
  * JWT_SECRET
  * MONGODB_PASS

### Setup

1. Clone the repository
2. Navigate to the project directory: `cd res_m_server/`
3. **Build the project**

If you have Gradle installed on your system, run:
  ```
  gradle build
  ```
If you don't have Gradle installed, use the Gradle wrapper included in the project:

- For Linux and macOS:

  ```
  ./gradlew build
  ```

- For Windows:

  ```
  gradlew.bat build
  ```

4. **Run the server**

After the build is successful, run the server using the following command:

- For Linux and macOS:

  ```
  ./gradlew run
  ```

- For Windows:

  ```
  gradlew.bat run
  ```

Alternatively, you can run the generated JAR file directly using the java command:
  ```
  java -jar build/libs/my-ktor-server-<version>.jar
  ```
Replace `<version>` with the appropriate version number for your project.

5. **Access the server**


The server should now be running. You can access it at http://localhost:8080 (or the port specified in your application.conf file) in your web browser or using an API testing tool like Postman.
