package com.example.utils


object Constants{

    const val DATABASE_NAME = "user_database"

}