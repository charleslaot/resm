package com.example.utils

import java.math.BigInteger
import java.security.MessageDigest

object Utils {

    fun md5Hash(email: String): String {
        val messageDigest = MessageDigest.getInstance("MD5")
        val digest = messageDigest.digest(email.toByteArray())
        val bigInt = BigInteger(1, digest)
        return bigInt.toString(16).padStart(32, '0')
    }
}