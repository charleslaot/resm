package com.example.di

import com.example.data.repository.MenuDataSource
import com.example.data.repository.MenuDataSourceImpl
import com.example.data.repository.UserDataSource
import com.example.data.repository.UserDataSourceImpl
import com.example.security.hashing.HashingService
import com.example.security.hashing.HashingServiceImpl
import com.example.security.token.TokenConfig
import com.example.security.token.TokenService
import com.example.security.token.TokenServiceImpl
import com.example.utils.Constants.DATABASE_NAME
import org.koin.dsl.module
import org.litote.kmongo.coroutine.coroutine
import org.litote.kmongo.reactivestreams.KMongo

val koinModule = module {
    val mongoPass = System.getenv("MONGODB_PASS")
    single {
        KMongo.createClient(
            connectionString = "mongodb+srv://jcnx-admin:$mongoPass@cluster0.4mjic94.mongodb.net/$DATABASE_NAME?retryWrites=true&w=majority"
        )
            .coroutine
            .getDatabase(DATABASE_NAME)
    }
    single<UserDataSource> {
        UserDataSourceImpl(get())
    }
    single<MenuDataSource> {
        MenuDataSourceImpl(get())
    }
    single<HashingService> {
        HashingServiceImpl()
    }
    single<TokenService> {
        TokenServiceImpl()
    }
}