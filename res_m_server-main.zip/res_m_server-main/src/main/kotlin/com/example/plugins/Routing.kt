package com.example.plugins

import com.example.data.repository.MenuDataSource
import com.example.data.repository.UserDataSource
import com.example.routes.*
import com.example.security.hashing.HashingService
import com.example.security.token.TokenConfig
import com.example.security.token.TokenService
import io.ktor.server.routing.*
import io.ktor.server.response.*
import io.ktor.server.application.*
import org.koin.ktor.ext.inject

fun Application.configureRouting(config: TokenConfig) {
    routing {
        val userDataSource by inject<UserDataSource>()
        val menuDataSource by inject<MenuDataSource>()
        val hashingService by inject<HashingService>()
        val tokenService by inject<TokenService>()



        signIn(
            userDataSource = userDataSource,
            hashingService = hashingService,
            tokenService = tokenService,
            tokenConfig = config
        )
        signUp(
            userDataSource = userDataSource,
            hashingService = hashingService
        )
        getMenus(
            menuDataSource = menuDataSource
        )
        addMenu(
            menuDataSource = menuDataSource
        )
        editMenu(
            menuDataSource = menuDataSource
        )
        deleteMenu(
            menuDataSource = menuDataSource
        )
        root(userDataSource)
        authenticate()
        getSecretInfo()

    }
}
