package com.example.security.token

data class TokenClaim(
    val name: String,
    val value: String
)
