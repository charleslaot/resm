package com.example.routes

import com.example.data.models.EndPoint
import com.example.data.repository.MenuDataSource
import com.example.data.requests.MenuRequest
import com.example.data.requests.SignInRequest
import com.example.data.responses.MenuResponse
import com.example.routes.authenticate
import com.example.utils.Utils
import io.ktor.http.*
import io.ktor.server.application.*
import io.ktor.server.auth.*
import io.ktor.server.auth.jwt.*
import io.ktor.server.request.*
import io.ktor.server.response.*
import io.ktor.server.routing.*

/**
 * Route for getting menus by owner ID.
 *
 * ## Example Request
 *
 * ```
 * GET /menus/{id}
 * ```
 *
 * ## Example Response
 *
 * HTTP status code: `200 OK`
 *
 * ```
 * {
 *   "menus": [
 *     {
 *       "name": "Lunch Menu",
 *       "picture": "https://example.com/lunch.jpg",
 *       "hidden": false,
 *       "plates": [
 *         {
 *           "name": "Salad",
 *           "description": "Fresh salad with dressing",
 *           "picture": "https://example.com/salad.jpg",
 *           "price": 9.99
 *         }
 *       ],
 *       "ownerId": "owner123",
 *       "id": "menu123"
 *     }
 *   ]
 * }
 * ```
 *
 * ### Bad Request
 *
 * HTTP status code: `400 Bad Request`
 */
fun Route.getMenus(
    menuDataSource: MenuDataSource
){
    get(EndPoint.Menus.path){
        val ownerId = call.parameters["id"]
        if (ownerId != null){
            val menus = menuDataSource.getMenusByOwnerId(ownerId = ownerId)
            call.respond(
                status = HttpStatusCode.OK,
                message = MenuResponse(
                    menus = menus
                )
            )
        }else{
            call.respond(HttpStatusCode.BadRequest, "Invalid Owner's ID")
        }
    }
}

/**
 * Authenticated route for adding new menus.
 *
 * ## Example Request
 *
 * ```
 * POST /menu/new
 * {
 *   "menu": {
 *     "name": "Dinner Menu",
 *     "picture": "https://example.com/dinner.jpg",
 *     "hidden": false,
 *     "plates": [
 *       {
 *         "name": "Steak",
 *         "description": "Grilled steak with potatoes",
 *         "picture": "https://example.com/steak.jpg",
 *         "price": 22.99
 *       }
 *     ],
 *     "ownerId": "owner123"
 *   },
 *   "menuId": null
 * }
 * ```
 *
 * ## Example Responses
 *
 * ### Menu Saved
 *
 * HTTP status code: `200 OK`
 *
 * ```
 * {
 *   "message": "Menu Saved"
 * }
 * ```
 *
 * ### Menu Already Exists
 *
 * HTTP status code: `409 Conflict`
 *
 * ```
 * {
 *   "message": "Menu Already Exists"
 * }
 * ```
 *
 * ### Menu could NOT be Saved
 *
 * HTTP status code: `409 Conflict`
 *
 * ```
 * {
 *   "message": "Menu could NOT be Saved"
 * }
 * ```
 *
 * ### Bad Request
 *
 * HTTP status code: `400 Bad Request`
 *
 * ### Unauthorized
 *
 * HTTP status code: `401 Unauthorized`
 *
 * ```
 * {
 *   "message": "Menu did not match User"
 * }
 * ```
 */
fun Route.addMenu(
    menuDataSource: MenuDataSource
){
    authenticate {
        post(EndPoint.AddNewMenu.path){
            val principal = call.principal<JWTPrincipal>()
            val userId = principal?.getClaim("userId", String::class)

            val request = kotlin.runCatching {
                call.receiveNullable<MenuRequest>()
            }.getOrNull() ?: kotlin.run {
                call.respond(HttpStatusCode.BadRequest)
                return@post
            }

            request.menu?.let { menu ->
                if(userId.equals(menu.ownerId)){
                    val (isSuccess, isExistingMenu) = menuDataSource.saveMenu(menu)
                    if (isSuccess) {
                        if (isExistingMenu) {
                            call.respond(
                                message = "Menu Already Exists",
                                status = HttpStatusCode.Conflict)
                        } else {
                            call.respond(
                                message = "Menu Saved",
                                status = HttpStatusCode.OK)

                        }
                    } else {
                        call.respond(
                            message = "Menu could NOT be Saved",
                            status = HttpStatusCode.Conflict)
                    }
                }else{
                    call.respond(
                        status = HttpStatusCode.Unauthorized,
                        message = "Menu did not match User"
                    )
                }
            } ?: run{
                call.respond(
                    status = HttpStatusCode.BadRequest,
                    message = "Menu was null"
                )
            }


        }
    }
}

/**
 * Authenticated route for editing menus.
 *
 * ## Example Request
 *
 * ```
 * POST /menu
 * ```
 *
 * ### Menu could NOT be Saved
 *
 * HTTP status code: `409 Conflict`
 *
 * ```
 * {
 *   "message": "Menu could NOT be Saved"
 * }
 * ```
 *
 * ### Bad Request
 *
 * HTTP status code: `400 Bad Request`
 *
 * ### Unauthorized
 *
 * HTTP status code: `401 Unauthorized`
 *
 * ```
 * {
 *   "message": "Menu did not match User"
 * }
 * ```
 */
fun Route.editMenu(
    menuDataSource: MenuDataSource
){
    authenticate {
        post(EndPoint.EditMenu.path){
            val principal = call.principal<JWTPrincipal>()
            val userId = principal?.getClaim("userId", String::class)

            val request = kotlin.runCatching {
                call.receiveNullable<MenuRequest>()
            }.getOrNull() ?: kotlin.run {
                call.respond(HttpStatusCode.BadRequest)
                return@post
            }

            request.menu?.let { menu ->
                if(userId.equals(menu.ownerId)){
                    val isSuccess = menuDataSource.updateMenu(menu)
                    if (isSuccess) {

                        call.respond(
                            message = "Menu Saved",
                            status = HttpStatusCode.OK)


                    } else {
                        call.respond(
                            message = "Menu could NOT be Saved",
                            status = HttpStatusCode.Conflict)
                    }
                }else{
                    call.respond(
                        status = HttpStatusCode.Unauthorized,
                        message = "Menu did not match User"
                    )
                }

            } ?: run{
                call.respond(
                    status = HttpStatusCode.BadRequest,
                    message = "Menu was null"
                )
            }



        }
    }
}

/**
 * Authenticated route for deleting menus.
 *
 * ## Example Request
 *
 * ```
 * POST /menu/delete/{id}
 * {
 *   "menu": null,
 *   "menuId": "menu123"
 * }
 * ```
 *
 * ## Example Responses
 *
 * ### Menu Deleted
 *
 * HTTP status code: `200 OK`
 *
 * ```
 * {
 *   "message": "Menu Deleted"
 * }
 * ```
 *
 * ### Menu could NOT be Deleted
 *
 * HTTP status code: `409 Conflict`
 *
 * ```
 * {
 *   "message": "Menu could NOT be Deleted"
 * }
 * ```
 *
 * ### Bad Request
 *
 * HTTP status code: `400 Bad Request`
 *
 * ```
 * {
 *   "message": "Invalid request body"
 * }
 * ```
 *
 * ### Unauthorized
 *
 * HTTP status code: `401 Unauthorized`
 *
 * ```
 * {
 *   "message": "Menu did not match User"
 * }
 * ```
 */
fun Route.deleteMenu(
    menuDataSource: MenuDataSource
){
    authenticate {
        post(EndPoint.DeleteMenu.path){
            val principal = call.principal<JWTPrincipal>()
            val userId = principal?.getClaim("userId", String::class)

            val request = kotlin.runCatching {
                call.receiveNullable<MenuRequest>()
            }.getOrNull() ?: kotlin.run {
                call.respond(HttpStatusCode.BadRequest, "Invalid request body")
                return@post
            }

            if (request.menuId.isNullOrEmpty()) {
                call.respond(HttpStatusCode.BadRequest, "Menu ID cannot be null or empty")
                return@post
            }

            val isTheUserOwner = menuDataSource.getMenusById(request.menuId)?.ownerId == userId

            if(isTheUserOwner){
                val isSuccess = menuDataSource.deleteMenu(request.menuId)
                if (isSuccess) {

                    call.respond(
                        message = "Menu Deleted",
                        status = HttpStatusCode.OK)


                } else {
                    call.respond(
                        message = "Menu could NOT be Deleted",
                        status = HttpStatusCode.Conflict)
                }
            }else{
                call.respond(
                    status = HttpStatusCode.Unauthorized,
                    message = "Menu did not match User"
                )
            }

        }
    }

}