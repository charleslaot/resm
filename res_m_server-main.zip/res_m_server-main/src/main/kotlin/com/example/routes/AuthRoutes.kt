package com.example.routes

import com.example.data.requests.SignUpRequest
import com.example.data.responses.AuthResponse
import com.example.data.models.EndPoint
import com.example.data.models.User
import com.example.data.repository.UserDataSource
import com.example.data.requests.SignInRequest
import com.example.security.hashing.HashingService
import com.example.security.hashing.SaltedHash
import com.example.security.token.TokenClaim
import com.example.security.token.TokenConfig
import com.example.security.token.TokenService
import com.example.utils.Utils
import io.ktor.http.*
import io.ktor.server.application.*
import io.ktor.server.auth.*
import io.ktor.server.auth.jwt.*
import io.ktor.server.request.*
import io.ktor.server.response.*
import io.ktor.server.routing.*
import org.apache.commons.codec.digest.DigestUtils

/**
 * Route handling sign-up requests.
 *
 *  *
 * Creates a new user with the provided information.
 *
 * ## Example Request
 *
 * ```
 * POST /signup
 * {
 *   "firstName": "John",
 *   "lastName": "Doe",
 *   "email": "john.doe@example.com",
 *   "password": "password123"
 * }
 * ```
 *
 * ## Example Responses
 *
 * ### User Saved
 *
 * HTTP status code: `200 OK`
 *
 * ```
 * {
 *   "message": "User Saved"
 * }
 * ```
 *
 * ### User Already Exists
 *
 * HTTP status code: `409 Conflict`
 *
 * ```
 * {
 *   "message": "User Already Exists"
 * }
 * ```
 *
 * ### User Could NOT be Saved
 *
 * HTTP status code: `409 Conflict`
 *
 * ```
 * {
 *   "message": "User could NOT be Saved"
 * }
 * ```
 *
 * ### Bad Request
 *
 * HTTP status code: `400 Bad Request`
 * @param hashingService The service used for hashing passwords.
 * @param userDataSource The data source for user-related operations.
 */
fun Route.signUp(
    hashingService: HashingService,
    userDataSource: UserDataSource
) {
    post(EndPoint.SingUp.path) {
        val request = kotlin.runCatching {
            call.receiveNullable<SignUpRequest>()
        }.getOrNull() ?: kotlin.run {
            call.respond(HttpStatusCode.BadRequest)
            return@post
        }

        val areFieldsBlank = request.firstName.isBlank() || request.lastName.isBlank() || request.email.isBlank() || request.password.isBlank()
//        val isPwTooShort = request.password.length < 8
//        if(areFieldsBlank || isPwTooShort) {
        if(areFieldsBlank) {
            call.respond(HttpStatusCode.Conflict)
            return@post
        }

        val saltedHash = hashingService.generateSaltedHash(request.password)
        val user = User(
            firstName = request.firstName,
            lastName = request.lastName,
            emailAddress = request.email,
            password = saltedHash.hash,
            salt = saltedHash.salt,
            phoneNumber = null

        )
        val (isSuccess, isExistingUser) = userDataSource.saveUser(user)
        if (isSuccess) {
            if (isExistingUser) {
                call.respond(
                    message = "User Already Exists",
                    status = HttpStatusCode.Conflict)
                return@post
            } else {
                call.respond(
                    message = "User Saved",
                    status = HttpStatusCode.OK)
                return@post

            }
        } else {
            call.respond(
                message = "User could NOT be Saved",
                status = HttpStatusCode.Conflict)
            return@post
        }



    }

    get ("/insert"){
        val password = "password"
        val saltedHash = hashingService.generateSaltedHash(password)
        val user = User(
            firstName = "name",
            lastName = "name",
            emailAddress = "name@gmail.com",
            password = saltedHash.hash,
            salt = saltedHash.salt,
            phoneNumber = null
            )
        val (isSuccess, isExistingUser) = userDataSource.saveUser(user)
        if (isSuccess) {
            if (isExistingUser) {
                call.respond(
                    message = "User Already Exists",
                    status = HttpStatusCode.Conflict)
            } else {
                call.respond(
                    message = "User Saved",
                    status = HttpStatusCode.OK)

            }
        } else {
            call.respond(
                message = "User could NOT be Saved",
                status = HttpStatusCode.Conflict)
        }

    }
}

/**
 * Route handling sign-in requests.
 *
 *  *
 * Authenticates a user with the provided email and password, and returns an access token if successful.
 *
 * ## Example Request
 *
 * ```
 * POST /signin
 * {
 *   "email": "john.doe@example.com",
 *   "password": "password123"
 * }
 * ```
 *
 * ## Example Responses
 *
 * ### Successful Sign-in
 *
 * HTTP status code: `200 OK`
 *
 * ```
 * {
 *   "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c"
 * }
 * ```
 *
 * ### Incorrect Username or Password
 *
 * HTTP status code: `409 Conflict`
 *
 * ```
 * {
 *   "message": "Incorrect username or password"
 * }
 * ```
 *
 * ### Bad Request
 *
 * HTTP status code: `400 Bad Request`
 *
 * @param userDataSource The data source for user-related operations.
 * @param hashingService The service used for hashing passwords.
 * @param tokenService The service used for generating tokens.
 * @param tokenConfig The configuration for token generation.
 */
fun Route.signIn(
    userDataSource: UserDataSource,
    hashingService: HashingService,
    tokenService: TokenService,
    tokenConfig: TokenConfig
) {
    post(EndPoint.SingIn.path) {
        val request = kotlin.runCatching {
            call.receiveNullable<SignInRequest>()
        }.getOrNull() ?: kotlin.run {
            call.respond(HttpStatusCode.BadRequest)
            return@post
        }

        val user = userDataSource.getUserByEmail(request.email)
        if(user == null) {
            call.respond(HttpStatusCode.Conflict, "Incorrect username or password")
            return@post
        }

        val isValidPassword = hashingService.verify(
            value = request.password,
            saltedHash = SaltedHash(
                hash = user.password,
                salt = user.salt
            )
        )
        if(!isValidPassword) {
            println("Entered hash: ${DigestUtils.sha256Hex("${user.salt}${request.password}")}, Hashed PW: ${user.password}")
            call.respond(HttpStatusCode.Conflict, "Incorrect username or password")
            return@post
        }

        val token = tokenService.generate(
            config = tokenConfig,
            TokenClaim(
                name = "userId",
                value = user.id
            )
        )

        call.respond(
            status = HttpStatusCode.OK,
            message = AuthResponse(
                token = token
            )
        )
    }
}

fun Route.authenticate() {
    authenticate {
        get("authenticate") {
            call.respond(HttpStatusCode.OK)
        }
    }
}

fun Route.getSecretInfo() {
    authenticate {
        get("secret") {
            val principal = call.principal<JWTPrincipal>()
            val userId = principal?.getClaim("userId", String::class)
            call.respond(HttpStatusCode.OK, "Your userId is $userId")
        }
    }
}