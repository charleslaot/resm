package com.example.routes

import com.example.data.models.User
import com.example.data.repository.UserDataSource
import io.ktor.server.application.*
import io.ktor.server.response.*
import io.ktor.server.routing.*

fun Route.root(
    userDataSource: UserDataSource
){
    get("/"){
        val mongoPass = System.getenv("MONGODB_PASS")
        call.respond("opassword is: $mongoPass")
    }

}