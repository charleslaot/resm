package com.example.data.requests

import kotlinx.serialization.Serializable

/**
 * Represents a sign-in request containing user's email and password.
 *
 * @property email The user's email address.
 * @property password The user's password.
 */
@Serializable
data class SignInRequest(
    val email: String,
    val password: String
)
