package com.example.data.models

/**
 * Represents a collection of API endpoints.
 */
sealed class EndPoint(val path: String){
    object SingUp: EndPoint(path = "/signup")
    object SingIn: EndPoint(path = "/signin")
    object Menus: EndPoint(path = "/menus/{id}")
    object AddNewMenu: EndPoint(path = "/menu/new")
    object EditMenu: EndPoint(path = "/menu/edit/{id}")
    object DeleteMenu: EndPoint(path = "/menu/delete/{id}")
}
