package com.example.data.repository

import com.example.data.models.Menu

interface MenuDataSource {
    suspend fun getMenusByOwnerId(ownerId: String): List<Menu>
    suspend fun getMenusById(id: String): Menu?
    suspend fun saveMenu(menu: Menu): Pair<Boolean, Boolean>
    suspend fun deleteMenu(id: String): Boolean
    suspend fun updateMenu(menu: Menu): Boolean
}