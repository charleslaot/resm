package com.example.data.models

import kotlinx.serialization.Serializable
import org.bson.codecs.pojo.annotations.BsonId
import org.bson.types.ObjectId

/**
 * Represents a user with various properties.
 *
 * @property id The unique identifier of the user.
 * @property firstName The user's first name.
 * @property lastName The user's last name.
 * @property emailAddress The user's email address.
 * @property password The user's hashed password.
 * @property salt The salt used in hashing the user's password.
 * @property phoneNumber The user's phone number (nullable).
 */
@Serializable
data class User(
    @BsonId val id: String = ObjectId().toHexString(),
    val firstName: String,
    val lastName: String,
    val emailAddress: String,
    val password: String,
    val salt: String,
    val phoneNumber: String?

)

