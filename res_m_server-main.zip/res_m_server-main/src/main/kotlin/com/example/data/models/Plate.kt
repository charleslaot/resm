package com.example.data.models

import kotlinx.serialization.Serializable

@Serializable
data class Plate(
    val name: String,
    val description: String,
    val picture: String?,
    val price: Float
)
