package com.example.data.requests

import kotlinx.serialization.Serializable

/**
 * Represents a sign-up request containing user's first name, last name, email, and password.
 *
 * @property firstName The user's first name.
 * @property lastName The user's last name.
 * @property email The user's email address.
 * @property password The user's password.
 */
@Serializable
data class SignUpRequest(
    val firstName: String,
    val lastName: String,
    val email: String,
    val password: String
)
