package com.example.data.responses

import com.example.data.models.Menu
import kotlinx.serialization.Serializable

@Serializable
data class MenuResponse(
    val menus: List<Menu>
)
