package com.example.data.repository

import com.example.data.models.User

interface UserDataSource {
    suspend fun getUserByEmail(emailAddress: String): User?
    suspend fun saveUser(user: User): Pair<Boolean, Boolean>
    suspend fun deleteUser(emailAddress: String): Boolean
    suspend fun updateUser(user: User): Boolean
}