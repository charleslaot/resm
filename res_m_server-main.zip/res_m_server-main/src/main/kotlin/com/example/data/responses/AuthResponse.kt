package com.example.data.responses

import com.example.data.models.UserSimplify
import kotlinx.serialization.Serializable

@Serializable
data class AuthResponse(
    val token: String
)
