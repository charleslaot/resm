package com.example.data.models

import kotlinx.serialization.Serializable

@Serializable
data class UserSimplify(
    val firstName: String,
    val lastName: String,
    val phoneNumber: String?,
    val ownerId: String,
)
