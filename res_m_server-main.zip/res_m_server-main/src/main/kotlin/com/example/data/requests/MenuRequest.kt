package com.example.data.requests

import com.example.data.models.Menu
import kotlinx.serialization.Serializable

@Serializable
data class MenuRequest(
    val menu: Menu?,
    val menuId: String?
)
