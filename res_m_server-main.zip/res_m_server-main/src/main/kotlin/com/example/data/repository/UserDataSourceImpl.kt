package com.example.data.repository

import com.example.data.models.User
import org.litote.kmongo.combine
import org.litote.kmongo.coroutine.CoroutineDatabase
import org.litote.kmongo.eq
import org.litote.kmongo.setValue

class UserDataSourceImpl(
    database: CoroutineDatabase
): UserDataSource {

    private val users = database.getCollection<User>()

    override suspend fun getUserByEmail(emailAddress: String): User? {
        return users.findOne(filter = User::emailAddress eq emailAddress)
    }

    override suspend fun saveUser(user: User): Pair<Boolean, Boolean> {
        val existingUser = users.findOne(filter = User::emailAddress eq user.emailAddress)
        return if (existingUser == null) {
            val isSuccess = users.insertOne(document = user).wasAcknowledged()
            Pair(isSuccess, false) // The first value indicates the success of the operation, and the second value indicates the user does not already exist
        } else {
            Pair(true, true) // The first value indicates the operation is successful, and the second value indicates the user already exists
        }
    }

    override suspend fun deleteUser(emailAddress: String): Boolean {
        return users.deleteOne(filter = User::emailAddress eq emailAddress).wasAcknowledged()
    }

    override suspend fun updateUser(user: User): Boolean {
        return users.updateOne(
            filter = User::emailAddress eq user.emailAddress,
            update = combine(
                setValue(User::firstName, user.firstName),
                setValue(User::lastName, user.lastName),
                setValue(User::phoneNumber, user.phoneNumber)
            )
        ).wasAcknowledged()
    }
}