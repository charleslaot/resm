package com.example.data.repository

import com.example.data.models.Menu
import org.litote.kmongo.combine
import org.litote.kmongo.coroutine.CoroutineDatabase
import org.litote.kmongo.eq
import org.litote.kmongo.setValue

class MenuDataSourceImpl(
database: CoroutineDatabase
): MenuDataSource {

    private val menus = database.getCollection<Menu>()

    override suspend fun getMenusByOwnerId(ownerId: String):List<Menu> {
        return menus.find(filter = Menu::ownerId eq ownerId).toList()
    }

    override suspend fun getMenusById(id: String): Menu? {
        return menus.findOne(filter = Menu::id eq id)
    }

    override suspend fun saveMenu(menu: Menu): Pair<Boolean, Boolean> {
        val existingMenu = menus.findOneById(menu.id)
        return if (existingMenu == null){
            val isSuccess = menus.insertOne(document = menu).wasAcknowledged()
            Pair(isSuccess, false) // The first value indicates the success of the operation, and the second value indicates the user does not already exist
        }else{
            Pair(true, true) // The first value indicates the operation is successful, and the second value indicates the user already exists
        }
    }

    override suspend fun deleteMenu(id: String): Boolean {
        return menus.deleteOne(filter = Menu::id eq id).wasAcknowledged()
    }

    override suspend fun updateMenu(menu: Menu): Boolean {
        return menus.updateOne(
            filter = Menu::id eq menu.id,
            update = combine(
                setValue(Menu::name, menu.name),
                setValue(Menu::picture, menu.picture),
                setValue(Menu::plates, menu.plates)
            )
        ).wasAcknowledged()
    }
}