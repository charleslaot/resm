# res_m_client
Client-side for Restaurant Menu Service

MVP Enviroment: https://resm.jcnxsolutions.com

## Installation

### Prerequisites

* [Node.js 14.6.0 or newer](https://nodejs.org/en/)

### Setup

1. Clone the repository
2. Install dependencies: `npm install`
3. Start the application:
   1. Local Development Server: `npm run dev`
   2. Local Production Server: `npm run build && npm run start`
