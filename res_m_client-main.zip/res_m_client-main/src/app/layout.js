import "./globals.css";
import Link from "next/link";

export const metadata = {
	title: "ResM",
	description: "JC&X RMS for businesses",
};

export default function RootLayout({ children }) {
	return (
		<html lang="en">
			<body>
				<nav>
					<Link href="/">Home</Link>
					<Link href="/signin">Sign In</Link>
					<Link href="/signup">Sign Up</Link>
				</nav>
				{children}
			</body>
		</html>
	);
}
