"use client";
import React, { useState } from "react";

function SignIn() {
	const [email, setEmail] = useState("");
	const [password, setPassword] = useState("");

	const handleSubmit = async (e) => {
		e.preventDefault();
		try {
			const response = await fetch("http://localhost:8080/signin", {
				method: "POST",
				headers: {
					"Content-Type": "application/json",
				},
				body: JSON.stringify({ email, password }),
			});

			if (response.ok) {
				const data = await response.json();
				console.log("Signed in:", data);
			} else {
				console.error("Sign-in failed:", response);
			}
		} catch (error) {
			console.error("Error:", error);
		}
	};

	return (
		<>
			<form onSubmit={handleSubmit}>
				<h2 style={{ color: "black" }}>Sign In</h2>
				<input type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} required />
				<input
					type="password"
					placeholder="Password"
					value={password}
					onChange={(e) => setPassword(e.target.value)}
					required
				/>
				<button type="submit">Sign In</button>
			</form>
		</>
	);
}

export default SignIn;
